close all; clear all; clc;

keyposes_compact=[];
for actionID=1:6
    pcmd=['load(' '''' 'CK_' num2str(actionID) '/CK_occ11_4layer_Bhattacharyya.mat' '''' ',' '''' 'dictionary' '''' ')' ';']
    actionID
    
    eval(pcmd);
    size(dictionary)
    keyposes_compact=[keyposes_compact dictionary];
end
save('CK_keyposes_compact_4layer_Bhattacharyya.mat','keyposes_compact');
size(keyposes_compact)
