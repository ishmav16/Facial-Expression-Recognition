 clear all,clc;
% im = imread('table1.jpg');
% hog = hog_feature_vector (im);
 %hog;
 descriptor = zeros(169, 1);
 fdimension = 8;
 [imflow,vx,vy,ggx,ggy] = demoflow();
 %imshow(imflow)
 [gx,gy] = gradient(double(vy));
 mag = sqrt(gx.*gx + gy.*gy);
 
 [Gx,Gy] = gradient(double(vx));
 mag1 = sqrt(Gx.*Gx + Gy.*Gy);

 rgx = gx.*Gx;
 rgy = gy.*Gy;
 mag2 = sqrt(rgx.*rgx + rgy.*rgy);
 imshow(mag2)
 
 directn = atan(rgx./(rgy+eps));
 velocity = abs(rgx + rgy * 1);
 descriptor(1:168, 1) = getDescriptor(directn, velocity, fdimension);
 descriptor(169,1) = 1;
 
 descriptor;
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %for Gwof
 
 des = zeros(169,1);
% [g1,g2] = gradient(rgb2gray(double(imflow)));
 Vx = ggx.*vx;
 Vy = ggy.*vy;
 directn1 = atan(Vy ./ (Vx+eps));
 velocity1 = abs(Vx + Vy * 1);
 des(1:168,1) = getDescriptor(directn1, velocity1, fdimension);
 des(169,1) = 1;
 
 des;
 
 %finvector = zeros(336,1);
 finvector = vertcat(descriptor,des);
 finvector
 