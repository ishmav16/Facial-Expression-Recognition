% % % % function OvercompleteDict1()

clear all, close all, clc
cond=0;
% % % % while(~cond)
action_names = cell(1,7);
action_names{4} = 'Happiness'; action_names{6} = 'Surprise'; action_names{2} = 'Disgust';
action_names{3} = 'Fear'; action_names{1} = 'Anger'; action_names{5} = 'Sorrow';action_names{7}='Test';

naction = length(action_names);
seqarray = 12;

codebook = [];

for actionID =1:6%%naction
    actionID

    data = [];
% % % %    pstr=['G:\Swapna_backup\ECSU_PC\AS_LAB\C\Back_up\Swapna\mountain\data\' action_names{actionID}];
   pstr=['data\' action_names{actionID}];
   p=dir(pstr);
   dirindex=[p.isdir];
   dirlist={p(dirindex).name}';
   n=size(dirlist,1);
    tenpercent=floor((n-2)/10);
    randnumbers=randperm(n-2);
    testIndex=randnumbers(1:tenpercent)+2;
    allIndex=[3:n];
    trainIndex=setdiff(allIndex,testIndex);
    pwd
    %%pause
    pt=strcat('save(', '''' , 'CK_trainIndex_',num2str(actionID),'.mat', '''',',','''','trainIndex', '''' , ');');
    eval(pt);
    pt=strcat('save(', '''' , 'CK_testIndex_',num2str(actionID),'.mat', '''',',','''','testIndex', '''' , ');');
    eval(pt);

    for seq =  trainIndex(1)%n-2%seqarray

        load(strcat('CK_', num2str(actionID), '/', 'CK_', action_names{actionID},'Seq',num2str(seq),'.mat'), 'descriptor');
        sizeofdescriptor=size(descriptor,2);
        data = [data [descriptor;(seq-2).*ones(1,sizeofdescriptor)]]; 
    end


dictionary = data(1:end-2,:);
pcmd=['save(' '''' 'CK_' num2str(actionID) '/CK_occ1_4layer.mat' '''' ',' '''' 'dictionary' '''' ')' ';'];
eval(pcmd);

size(data,2)


%normalization

mindata=min(data,[],2);
maxdata=max(data,[],2);

atrootnodesizeofdata=size(data,2)


%first column stores number of data stored in next columns
result=[];
queue=[repmat(size(data,2), size(data,1),1) data];
[sm s]=size(queue);
count=0;
cc=0;
%stop at level 'level of max-diff-kd-tree
level=4;
%'finalcc' times divide d root
finalcc=2^level-1
variance=var(data(1:end-2,:),0,2);
[maxvar ind]=max(variance);
while  s~=0
        data=queue(:,2:1+queue(1,1));
        queue=queue(:,queue(1,1)+2:end);
        [ind class1 class2]=func(data,maxvar);
        cc=cc+1;
        if ind==0
            size(data,2)
            var1=var(data(1:end-2,:),0,2);
            result=[result repmat(size(data,2), size(data,1), 1) data]; 
        else
            queue=[queue repmat(size(class1,2), size(class1,1), 1) class1];
            queue=[queue repmat(size(class2,2), size(class2,1), 1) class2];
        end
        if cc==finalcc
            break;
        end
        s=size(queue,2);
end
if(cc==finalcc)
    cc
    count=2^level
    count1=count
else
    cc
    finalcc
end
result=[result queue zeros(size(queue,1),1)];
    
count;
KDTreeDone=1;
resultSize=size(result)
% %%pause



% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%block for displaying poses from same cluster                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
action_names = cell(1,7);
action_names{4} = 'Happiness'; action_names{6} = 'Surprise'; action_names{2} = 'Disgust';
action_names{3} = 'Fear'; action_names{1} = 'Anger'; action_names{5} = 'Sorrow';action_names{7}='Test';
ptr1=0;
ptr2=0;
pp=1;
while(result(1,ptr2+1)~=0)
ptr1 = ptr2+2;
ptr2=result(1,ptr1-1)+ptr2+1;
tempdictionary=result(:,ptr1:ptr2);
result;
sizeoftempdictionary=size(tempdictionary,2);
    ccc=0;
 

   p=dir(pstr);
   dirindex=[p.isdir];
   dirlist={p(dirindex).name}';
   n=size(dirlist,1);

   
       for seq =  trainIndex %n-2%seqarray
        load(strcat('CK_', num2str(actionID), '/','CK_',action_names{actionID},'Seq',num2str(seq),'.mat'), 'descriptor');
        dirpath=fullfile(pstr,dirlist{seq});
        q=dir(char(dirpath));
        dirindex1=[q.isdir];
        filenames={q(~dirindex1).name}';
        m=size(filenames,1);


       count=1;
        
        for i = 1 : size(descriptor, 2)
            [closest index] = getCodeword(descriptor(1:end-1,i), tempdictionary(1:end-1,:));
            closest;
            i;
            if (closest<0.005)

                fname=char(fullfile(dirpath,filenames{count}));
                
                
                
                im=imread(fname);
                ccc=ccc+1;
                if(ccc>25)
                    break;
                end
               figure(1), subplot(5, 5, ccc), imagesc(im), colormap gray, axis off
               
                                 
            end
            count = count + 1;
            
       
        end
         if(ccc==16)
            break;
         end
     end
    pp=pp+1;
end


%end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%block for choosing cluster representatives                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


sizeofresult=size(result,2)
%%%%count=count1;
dictionary=[];
% % % % for i=1:count
while(result(1,1)~=0)
    data=result(:,2:result(1,1)+1);
    n=result(1,1);
    result=result(:,n+2:end);
    if(n>2)
   
    dist=zeros(1,n);
    hist=zeros(1,n);
    for j=1:n
        for k=1:n
           dist(k)=sum(sqrt((data(1:end-2,j)/sum(data(1:end-2,j))).*(data(1:end-2,k)/sum(data(1:end-2,k)))));
        end
        [val inx]=sort(dist);
        hist(inx(end-1))=hist(inx(end-1))+1;
    end
    [maxhist maxindx]=max(hist);
    dictionary=[dictionary data(:,maxindx)];
    
    else
         dictionary=[dictionary data(1:end,1)];
    end
        
end
ClusterRepresentativeChoosen=1
sizeofdictionary=size(dictionary,2)


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%block for displaying key poses after max_dif_kd_tree
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%for actionID = 1 : 3%%%naction
    ccc=0;
   p=dir(pstr);
   dirindex=[p.isdir];
   dirlist={p(dirindex).name}';
      % % % %    validdirindex=~ismember(dirlist,{'.','..'});
   n=size(dirlist,1);
     
   
    for seq =  trainIndex %n-2
       load(strcat('CK_', num2str(actionID), '/','CK_', action_names{actionID},'Seq',num2str(seq),'.mat'), 'descriptor');
       dirpath=fullfile(pstr,dirlist{seq});
        q=dir(char(dirpath));
        dirindex1=[q.isdir];
        filenames={q(~dirindex1).name}';
        m=size(filenames,1);


       count=1;
        for i = 1 : size(descriptor, 2)
            [closest index] = getCodeword(descriptor(1:end-1,i), dictionary(1:end-1,:));
            closest;
            i;
            if (closest<0.001)
                index;
               
                 fname=char(fullfile(dirpath,filenames{count}));
                im=imread(fname);
                ccc=ccc+1;
                if(ccc>25)
                    break
                end
                figure(pp+1), subplot(5, 5, ccc), imagesc(im), colormap gray, axis off
               
            end
            count = count + 1;
        end
        if(ccc>25)
                    break
        end
    end
pcmd=['save(' '''' 'CK_' num2str(actionID) '/CK_occ11_4layer_Bhattacharyya.mat' '''' ',' '''' 'dictionary' '''' ')' ';']
eval(pcmd);
actionID
end
keypose_concat
classifyaction2;
%crossvalidation_Swapnadi_new_for_poly
% % % cond=mean(cm(end,:))>90 && cm(end,1)>60 && cm(end,2)>60 && cm(end,3)>60 && cm(end,4)>60 && cm(end,5)>60 && cm(end,6)>60
% % % 
% % % end



   

    
            
    

            
            

