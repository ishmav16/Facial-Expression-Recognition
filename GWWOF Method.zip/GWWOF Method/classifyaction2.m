
clear all, close all, clc

action_names = cell(1,7);

action_names{4} = 'Happiness'; action_names{6} = 'Surprise'; action_names{2} = 'Disgust';
action_names{3} = 'Fear'; action_names{1} = 'Anger'; action_names{5} = 'Sorrow';action_names{7}='Test';


testvideofeature=[];

sigma =0.3; %%% Try out by hand
% load keyposes_compact_4layer_Bhattacharyya_8_1_2graph_centers.mat keyposes_compact;
%/@/load('CK/CK_keyposes_compact_4layer_Bhattacharyya.mat','keyposes_compact');
load('CK_keyposes_compact_4layer_Bhattacharyya.mat','keyposes_compact');
% load C:\Users\Swapna\Desktop\keyposes_compact_4layer_Bhattacharyya_8_1_2graph_centers.mat keyposes_compact;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Extract Video Features for a given video sequence
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta=0.01;
niter=31;
for iter=1:niter
    videofeature = [];
    nsmd=0;
    nsmd_pre=0;
for actionID = 1 :6% naction
%     actionID
    fprintf('\n New activity %s begins \n', action_names{actionID});
% % % %     pstr=['C:\Back_up\Swapna\mountain\data\' action_names{actionID}];
% % % %     pstr=['C:\programs\TIFS\traininig_for_EM_MUG\images\' action_names{actionID}];
    pstr=['F:\Swapna_backup\ECSU_PC\AS_LAB\C\Back_up\Swapna\mountain\data\' action_names{actionID}];
    p=dir(pstr);
    dirindex=[p.isdir];
    dirlist={p(dirindex).name}';
% % % %    validdirindex=~ismember(dirlist,{'.','..'});
    n=size(dirlist,1);

%/@/pt=strcat('load(', '''' , 'CK/CK_trainIndex_',num2str(actionID),'.mat', '''',',','''','trainIndex', '''' , ');');
pt=strcat('load(', '''' , 'CK_trainIndex_',num2str(actionID),'.mat', '''',',','''','trainIndex', '''' , ');');
eval(pt);
           %/@/pcmd=['load(' '''' 'CK/CK_' num2str(actionID) '/CK_occ11_4layer_Bhattacharyya.mat' '''' ',' '''' 'dictionary' '''' ')' ';'];
           pcmd=['load(' '''' 'CK_' num2str(actionID) '/CK_occ11_4layer_Bhattacharyya.mat' '''' ',' '''' 'dictionary' '''' ')' ';'];
           eval(pcmd);
 
           nsmd_pre=nsmd_pre+nsmd;
           nsmd=size(dictionary,2);
           
    for seq = trainIndex %n-2 %seqarray
        SD = zeros(1, size(keyposes_compact, 2)); 
        %/@/load(strcat('CK/CK_', num2str(actionID), '/', 'CK_', action_names{actionID},'Seq',num2str(seq),'.mat'), 'descriptor');
        load(strcat('CK_', num2str(actionID), '/', 'CK_', action_names{actionID},'Seq',num2str(seq),'.mat'), 'descriptor');
        for k = 1 : size(descriptor, 2) 
            d = repmat(descriptor(1:end-1,k)/sum(descriptor(1:end-1,k)), 1, size(keyposes_compact, 2));
            keyposes_compact1=zeros(size(keyposes_compact(1:end-2,:)));
            for i=1:size(keyposes_compact,2)
                keyposes_compact1(:,i)=keyposes_compact(1:end-2,i)/sum(keyposes_compact(1:end-2,i));
            end
            a=find(keyposes_compact1<0);
            a=a(:);
            if(size(a,1))>0
               keyposes_compact1LessThanZero=1
               seq-2
               k
               a
               %%pause
            end
            a=find(d<0);
            a=a(:);
            if(size(a,1))>0
               dLessThanZero=1
               seq-2
               k
               a
               
               %%pause
           end
           
           dist=sqrt(1-sum(sqrt(d.*keyposes_compact1),1));
           a=find(dist<0);
           a=a(:);
           if(size(a,1))>0
               seq-2
               k
               a
               %%pause
           end
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           
       if iter<niter
           [val ind]=min(dist(nsmd_pre+1:nsmd_pre+nsmd));
           ind=ind+nsmd_pre;
           keyposes_compact(1:end-2,ind)=keyposes_compact(1:end-2,ind)-delta*(keyposes_compact(1:end-2,ind)-descriptor(1:end-1,k));
       end
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % %             [val index] =min(dist);
% % % %             %val=sqrt(val);
% % % %              SD(index) = SD(index) + exp(-1* dist(index)/(sigma.^2));
% % % % %              if iter==niter
% % % % % % % %                  SD = SD + exp(-1* dist./(sigma.^2));
% % % % % % % %              SD(index) = SD(index) + 1;
% % % % %              end
        end
% % % % %         if iter==niter
% % % %             SD = SD/sum(SD); %%% normalize the video feature vector
% % % %             videofeature = [videofeature; SD actionID];
% % % % %         end
    end
end


fprintf('iter %d done \n',iter);
end
keyposes_compact_adapted=keyposes_compact;
%/@/%save('CK\CK_keyposes_compact_adapted_4layer_Bhattacharyya.mat','keyposes_compact_adapted');
save('CK_keyposes_compact_adapted_4layer_Bhattacharyya.mat','keyposes_compact_adapted');
% % % % keyposes_compact= keyposes_compact_adapted;

% % % % load('CK/CK_keyposes_compact_4layer_Bhattacharyya.mat','keyposes_compact');
videofeature = [];
tic
for actionID = 1 :6% naction
   fprintf('\n New activity %s begins \n', action_names{actionID});
   %/@/pt=strcat('load(', '''' , 'CK/CK_trainIndex_',num2str(actionID),'.mat', '''',',','''','trainIndex', '''' , ');');
   pt=strcat('load(', '''' , 'CK_trainIndex_',num2str(actionID),'.mat', '''',',','''','trainIndex', '''' , ');');
   eval(pt);
   size(trainIndex)
    for seq = trainIndex%(1)
        SD = zeros(1, size(keyposes_compact, 2)); %%% initialize frequency counter/histogram
        %/@/load(strcat('CK/CK_', num2str(actionID), '/','CK_', action_names{actionID},'Seq',num2str(seq),'.mat'), 'descriptor');
        load(strcat('CK_', num2str(actionID), '/','CK_', action_names{actionID},'Seq',num2str(seq),'.mat'), 'descriptor');
        for k = 1 : size(descriptor, 2) 
            d = repmat(descriptor(1:end-1,k)/sum(descriptor(1:end-1,k)), 1, size(keyposes_compact, 2));
            keyposes_compact1=zeros(size(keyposes_compact(1:end-2,:)));
            for i=1:size(keyposes_compact,2)
                keyposes_compact1(:,i)=keyposes_compact(1:end-2,i)/sum(keyposes_compact(1:end-2,i));
            end
            dist=sqrt(1-sum(sqrt(d.*keyposes_compact1),1));
            [val index] =min(dist);
            dist;
            SD;
            SD(index) = SD(index) + exp(-1* val/(sigma.^2));
            SD;
        end
        %SD = SD/sum(SD,2); %%% normalize the video feature vector
        videofeature = [videofeature; SD actionID];
        videofeature
    end
% % % %         for k = 1 : size(descriptor, 2) %%% construct video feature for "seq"th video sequence
% % % %             d = repmat(descriptor(:,k), 1, size(keyposes_compact, 2));
% % % %             dist = (d - keyposes);
% % % %             dist = dist.*dist;
% % % %             decision = sum(dist, 1);
% % % %             [val index] = min(decision);
% % % %             SD(index) = SD(index) + exp(-1* val/(sigma.^2));
% % % %         end
% % % %         SD = SD/sum(SD); %%% normalize the video feature vector
% % % %         testvideofeature = [testvideofeature; SD 2];
% % % %     end
end
t3=toc;
pt=strcat('save(', '''' , 'CK/CK_train_kernel_niter_is_31_iter_is_',num2str(iter-1),'.txt', '''',',','''','videofeature', '''', ',' ,'''' , '-ASCII','''', ');');
eval(pt);
pt=strcat('save(', '''' , 'CK/CK_train_kernel_niter_is_31_iter_is_',num2str(iter-1),'.mat', '''',',','''','videofeature', '''',  ');');
eval(pt);

%%Allam gaadi Valuables.......

% % save('testvideofeature.mat','testvideofeature');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Get ready for classification and ROC analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 %d = size(videofeature, 2);
 %dataset = videofeature(:,1 : d - 1);
 %groups = videofeature(:, d);
 
% % % % 
 %for i = 1 : 3%length(action_names)
% % % %     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  classindex = (groups == i);
  %  data = [dataset classindex];
     %%% Now feed the data to drawSVMroc.m
% % % %     %%% and get ROC curve and accuracy for each action
% % % %     %%% Accuracy value is used for confusion matrix
 %     i
%end
%save('videofeature_mountain_compact_4layer_Bhattacharyya_sigma_0point2.mat', 'videofeature');
%save('videofeature_plausibility_8_1_2graph_centers.mat','videofeature');
%save('test_8_1_2.mat','videofeature');
%save('test_8_1_2.txt','videofeature','-ASCII');
%save('keyposes_compact_4layer_Bhattacharyya_final.mat','keyposes_compact');