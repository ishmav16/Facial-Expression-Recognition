function [ind class1 class2]=func(data,maxvar)
sizeofdata=size(data,2);
% % % % if(sizeofdata==15)
% % % %     data
% % % % end
if size(data,2)<25
    ind=0;
    class1=[];
    class2=[];
    return
end

variance=var(data(1:end-2,:),0,2);
[submaxvar ind]=max(variance);  
submaxvar;
maxvar;
if submaxvar<maxvar*0.5
    ind=0
%         submaxvarIsLessThanHalfOfmaxvar
%         pause
    class1=[];
    class2=[];
    return;
% % % % else if size(data,2)==2
% % % %         maxvar
% % % %         submaxvar
% % % %     end
    
end
    
maxi=zeros(1,size(data(1:end-2,:),1));
pivot=zeros(3,size(data(1:end-2,:),1));
lb=max(floor(size(data(1:end-2,:),2)*10/100),5);
ub=min(ceil(size(data(1:end-2,:),2)*90/100),size(data,2)-5);


if(lb==0)
    lb=0
    pause
    lb=1;
    ub=size(data,2);
end



    

for i=1:size(data(1:end-2,:),1)
    data1=data(i,:);
    [val indx]=sort(data1);
    maxi(i)=val(lb+1)-val(lb);
    pivot(1,i)=(val(lb+1)-val(lb))/2+val(lb);
    pivot(2,i)=val(lb+1);
    pivot(3,i)=val(lb);
    for j=lb+1:ub-1
        if maxi(i)<val(j+1)-val(j)
            maxi(i)=val(j+1)-val(j);
            pivot(1,i)=(val(j+1)-val(j))/2+val(j);
            pivot(2,i)=val(j+1);
            pivot(3,i)=val(j);
        end
    end
end
% % % % 
% % % % if(size(data1,2)==285  )
% % % %         
% % % %         find(maxi>0.444);
% % % %         maxi(find(maxi>0.444));
% % % %         data;
% % % % end 
% % % %     if(size(data1,2)==283  )
% % % %         
% % % %          find(maxi>0.444);
% % % %          maxi( find(maxi>0.444));
% % % %         
% % % %     end   
% % % %     if(size(data1,2)==2  )
% % % %        
% % % %          find(maxi>0.444);
% % % %          maxi( find(maxi>0.444));
% % % %           data;
% % % %     end   
maxi1=maxi(1);
pivot1=pivot(1,1);
piv1=pivot(2,1);
piv2=pivot(3,1);
ind=1;
for i=2:size(data(1:end-2,:),1)
    if maxi1<maxi(i)
        maxi1=maxi(i);
        pivot1=pivot(1,i);
        ind=i;
        piv1=pivot(2,i);
        piv2=pivot(3,i);
    end
end
maxi1;
piv1;
piv2;

figure(1);
plot(data(ind,:),ones(1,size(data,2)),'+g');
% % % %  if(size(data1,2)==2  )
% % % %      pause
% % % %  end
% % % % pause;

if maxi1<0.05
    pp=find(data<0);
    pp
    variance=var(data(1:end-2,:),0,2);
    [maxvar ind]=max(variance);
    if maxvar>=0.05
%         maxi1
%         maxvar
%         pause
        meanval=mean(data(ind,:));
        pivot1=meanval;
    else
        ind=0;
    end
end
class1=[];
class2=[];
if ind ~=0
    for i=1:size(data,2)
        if data(ind,i)<pivot1
            class1=[class1 data(:,i)];
        else
            class2=[class2 data(:,i)];
        end
    end
    if(size(class1,2)<5)
        ind=0;
        class1=[];
        class2=[];
        return;
    end
    if(size(class2,2)<5)
        ind=0;
        class1=[];
        class2=[];
        return;
    end
end
end
