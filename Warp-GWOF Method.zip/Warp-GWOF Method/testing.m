
clear all,clc;

practice1();