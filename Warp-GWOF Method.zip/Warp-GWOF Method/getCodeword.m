function [val index] = getCodeword(x, vocab)
n = size(vocab, 2);
distM = zeros(1, size(vocab, 2));
for i = 1 : n
%          distM(i) = sum((x - vocab(1:end-1,i)).^2).^0.5; 
          distM(i)=1-sum(sqrt((x/sum(x)).*(vocab(1:end-1,i)/sum(vocab(1:end-1,i)))));
end
% [val index] = min(distM(1,:));
[val index] =min(distM(1,:));
end