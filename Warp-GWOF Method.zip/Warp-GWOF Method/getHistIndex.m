function [layers_all] = getHistIndex(basket, r, c, row, col, fdimension,layer)
layers_all=zeros(1,layer);
layers_all(1)=basket;
for lc=2:layer
lr=ceil(r/ceil(row/(2^(lc-1))));
lcr=ceil(c/ceil(col/(2^(lc-1))));
layers_all(lc)=(lr-1)*fdimension*(2^(lc-1))+(lcr-1)*fdimension+basket;
%lc

end
%layers_all
% layers_all = zeros(1, 3);
% layers_all(1) = basket;
% 
% L2r = ceil(r/ceil(row/2)); L3r = ceil(r/ceil(row/4));
% L2c = ceil(c/ceil(col/2)); L3c = ceil(c/ceil(col/4));
% 
% layers_all(2) = (L2r - 1) * fdimension * 2 + (L2c - 1) * fdimension + basket;
% layers_all(3) = (L3r - 1) * fdimension * 4 + (L3c - 1) * fdimension +
% basket;