function practice1()
addpath('demoflow');
%addpath('Opticalflow');
addpath('OF\toolbox\images');
addpath 'OF\toolbox\filters';
fdimension = 8;
action_names = cell(1,7);
action_names{4} = 'Happiness'; action_names{6} = 'Surprise'; action_names{2} = 'Disgust';
action_names{3} = 'Fear'; action_names{1} = 'Anger'; action_names{5} = 'Sorrow'; action_names{7}='Test';
naction = length(action_names);
seqarray = 12;
for actionID = 1 :6 %naction
% % % %    pstr=['G:\Swapna_backup\ECSU_PC\AS_LAB\C\Back_up\Swapna\mountain\data\' action_names{actionID}];
   pstr=['data\' action_names{actionID}];
   p=dir(pstr);
   dirindex=[p.isdir];
   dirlist={p(dirindex).name}';
   n=size(dirlist,1);
   p1=['mkdir(' '''' 'CK_' num2str(actionID) '''' ')'];
   eval(p1);
   pcmd=strcat('load CK\CK_positions',num2str(actionID));
   eval(pcmd);

   
   pc=strcat('positions=positions',num2str(actionID),';');
   eval(pc);
   positions=abs(floor(positions+0.5));
   for seq =3 :n%seqarray
        flag = true;

    dirpath=fullfile(pstr,dirlist{seq});
    q=dir(char(dirpath));
    dirindex1=[q.isdir];
    filenames={q(~dirindex1).name}';
    m=size(filenames,1);
    example = filenames;
    descriptor = zeros(169, m);
    for count=2:m
        
            fname=char(fullfile(dirpath,filenames{count}));
            fname_old=char(fullfile(dirpath,filenames{count-1}));

            if exist(fname, 'file')
                if( strcmp(fname(end-1:end),'db'))
                    continue;
                end
                vmatrix_tmp = imread(fname);

                vmatrix_tmp=vmatrix_tmp(positions(seq-2,1):positions(seq-2,3),positions(seq-2,2):positions(seq-2,4));

                vmatrix_old_tmp=imread(fname_old);

                vmatrix_old_tmp=vmatrix_old_tmp(positions(seq-2,1):positions(seq-2,3),positions(seq-2,2):positions(seq-2,4));
              
                sz1=size(vmatrix_tmp);
                sz2=size(vmatrix_old_tmp);
                if sz1~=sz2
                    SizesDntMatch=1
                    %%pause
                    if sz1(1)<sz2(1)
                        x=1+ceil((sz2(1)-sz1(1))/2):sz2(1)-floor((sz2(1)-sz1(1))/2)
                        y=1+ceil((sz2(2)-sz1(2))/2):sz2(2)-floor((sz2(2)-sz1(2))/2)
                        vmatrix=vmatrix_tmp;
                        vmatrix_old=vmatrix_old_tmp(x,y);
                    else
                        x=1+ceil((sz1(1)-sz2(1))/2):sz1(1)-floor((sz1(1)-sz2(1))/2)
                        y=1+ceil((sz1(2)-sz2(2))/2):sz1(2)-floor((sz1(2)-sz2(2))/2)
                        vmatrix=vmatrix_tmp(x,y);
                        vmatrix_old=vmatrix_old_tmp;
                    end
                else
                    vmatrix=vmatrix_tmp;
                    vmatrix_old=vmatrix_old_tmp;
                end

               
                [vx,vy,Gmag,Gdir,ggx,ggy] = demoflow(vmatrix_old, vmatrix,example);
                Vx = ggx.*vx;
                Vy = ggy.*vy;
                [k1,k2] = gradient(double(Vx));
                ma = sqrt((k1.*k1 + k2.*k2));
            %    imshow(ma);
                directn = atan2(Vy,(Vx+eps));
                velocity = abs(Vx + Vy * i);
                t1=toc;
                [descriptor(1:end-1, count)] = getDescriptor(directn, velocity, fdimension);
                descriptor(end,count) = count-1;
                clear('vmatrix', 'vmatrix_old', 'vmatrix_tmp', 'vmatrix_old_tmp');
            else
                flag=false;
                
    end
   
    end
     save(strcat('CK_', num2str(actionID),'/','CK_',action_names{actionID},'Seq',num2str(seq), '.mat'), 'descriptor');
end
end