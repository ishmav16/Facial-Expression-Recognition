%function drawSVMroc()

close all, clear all, clc

%load videofeature_4_svm.mat videofeature
load 'CK\CK_train_kernel_niter_is_31_iter_is_30.mat'
p = 0;
for i = 1 : 12
    test = []; train =[]; trainlabel = [];
    for j = 1 : 12        
        if j == i%mod(i,12)
            test = [test; videofeature(j,2:6)];
            testlabel = 1;
        else
            train = [train; videofeature(j,2:6)];
            trainlabel = [trainlabel; (videofeature(j,7)==videofeature(i,7))];
        end
    end
    train;
    trainlabel
    svmStruct = svmtrain(train,trainlabel);
    classes = svmclassify(svmStruct,test);
    if classes == testlabel
        p = p + 1;
    end
     fprintf('\n Sequence %d: correct class %d Estimated class %d\n',...
         i, testlabel, classes);
    clear test train trainlabel
    if (mod(i,12) == 0)
        (p/12)*100
        p = 0;
    end
end
