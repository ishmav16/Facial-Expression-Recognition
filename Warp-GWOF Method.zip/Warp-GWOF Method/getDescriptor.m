function [descriptor] = getDescriptor(directn, velocity, fdimension)

layer1 = zeros(8,1);
layer2 = zeros(4*8,1);
layer3 = zeros(16*8,1);
[row col] = size(velocity);
max(velocity);
HOG_DIMENSION = 8;

for r = 1 : row
    for c = 1 : col

        for basket = 1 : HOG_DIMENSION
            if directn(r, c) > (-pi/2 + ...
                    (pi/HOG_DIMENSION) * basket)
                continue
            else
                basketLayerwise = getHistIndex(basket, r, c, row, col, fdimension);
                layer1(basketLayerwise(1)) = layer1(basketLayerwise(1)) + velocity(r, c);
                layer2(basketLayerwise(2)) = layer2(basketLayerwise(2)) + velocity(r, c);
                layer3(basketLayerwise(3)) = layer3(basketLayerwise(3)) + velocity(r, c);
                break
            end
        end
    end
end
layer1 = layer1/sum(layer1);
layer2 = layer2/sum(layer2);
layer3 = layer3/sum(layer3);

descriptor = [layer1; layer2; layer3];

% denom = sum(descriptor) + eps;
% descriptor = descriptor/denom;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [layers_all] = getHistIndex(basket, r, c, row, col, fdimension)

layers_all = zeros(1, 3);
layers_all(1) = basket;

L2r = ceil(r/ceil(row/2)); L3r = ceil(r/ceil(row/4));
L2c = ceil(c/ceil(col/2)); L3c = ceil(c/ceil(col/4));

layers_all(2) = (L2r - 1) * fdimension * 2 + (L2c - 1) * fdimension + basket;
layers_all(3) = (L3r - 1) * fdimension * 4 + (L3c - 1) * fdimension + basket;
end 